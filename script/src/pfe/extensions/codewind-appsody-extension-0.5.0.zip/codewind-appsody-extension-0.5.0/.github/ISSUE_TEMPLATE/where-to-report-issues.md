---
name: "⚠️ Where to report issues?"
about: File issues in the main Eclipse Codewind repository at https://github.com/eclipse/codewind/issues
title: Issues need to be filed in the main Eclipse Codewind repository
labels: ''
assignees: ''

---

## Where to report issues?

This repository is not used for issue tracking of the Codewind Appsody extension

🚨 Please don't submit new issues here. 🚨

All issues for the Eclipse Codewind Appsody extension are managed at [https://github.com/eclipse/codewind/issues](https://github.com/eclipse/codewind/issues).
